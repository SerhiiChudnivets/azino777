function  showMore(){
    $("#text_block").toggleClass('open');
}

function toggleMenu() {
    $(".collapse__menu").toggleClass("open-menu");
}