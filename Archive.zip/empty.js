function toggleMenu() {
    console.log(event.target.closest(".hamburger"))
    $(".collapse__menu").toggleClass("open-menu");

}

function  showMore(){
    $("#text_block").toggleClass('open');
}